﻿// Decompiled with JetBrains decompiler
// Type: LoneRobot.UI.My.MyComputer
// Assembly: HitchHiker, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0532B763-C6E8-474A-A94B-4B81B2597EA1
// Assembly location: C:\Users\zahid\Desktop\HitchHiker.dll

using Microsoft.VisualBasic.Devices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;

namespace LoneRobot.UI.My
{
  [EditorBrowsable(EditorBrowsableState.Never)]
  [GeneratedCode("MyTemplate", "8.0.0.0")]
  internal class MyComputer : Computer
  {
    [DebuggerHidden]
    [EditorBrowsable(EditorBrowsableState.Never)]
    public MyComputer()
    {
    }
  }
}
