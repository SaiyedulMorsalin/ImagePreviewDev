﻿// Decompiled with JetBrains decompiler
// Type: LoneRobot.UI.My.Resources.Resources
// Assembly: HitchHiker, Version=2.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 0532B763-C6E8-474A-A94B-4B81B2597EA1
// Assembly location: C:\Users\zahid\Desktop\HitchHiker.dll

using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace LoneRobot.UI.My.Resources
{
  [GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "2.0.0.0")]
  [CompilerGenerated]
  [StandardModule]
  [HideModuleName]
  [DebuggerNonUserCode]
  internal sealed class Resources
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (object.ReferenceEquals((object) LoneRobot.UI.My.Resources.Resources.resourceMan, (object) null))
          LoneRobot.UI.My.Resources.Resources.resourceMan = new ResourceManager("LoneRobot.UI.Resources", typeof (LoneRobot.UI.My.Resources.Resources).Assembly);
        return LoneRobot.UI.My.Resources.Resources.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => LoneRobot.UI.My.Resources.Resources.resourceCulture;
      set => LoneRobot.UI.My.Resources.Resources.resourceCulture = value;
    }

    internal static Bitmap avi => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (avi), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap aviL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (aviL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap bmp => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (bmp), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap bmpL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (bmpL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap border_all => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (border_all), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap calendar_16 => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (calendar_16), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap clock => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (clock), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap cross => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (cross), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap delete => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (delete), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap directory => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (directory), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap down_16 => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (down_16), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap empty => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (empty), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap FilmStrip => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (FilmStrip), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap folder => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (folder), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap font_color => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (font_color), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap globe_16 => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (globe_16), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap Help => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (Help), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap image_star => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (image_star), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap jpg => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (jpg), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap jpgL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (jpgL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap max => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (max), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap MaxL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (MaxL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap minus => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (minus), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap options => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (options), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap pictures_thumbs16 => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (pictures_thumbs16), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap plus => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (plus), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap png => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (png), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap PngL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (PngL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap psd => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (psd), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap PsdL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (PsdL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap purple_robot_small_posed => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (purple_robot_small_posed), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap refresh => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (refresh), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap rpf => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (rpf), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap RpfL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (RpfL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap seasons => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (seasons), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap sort_ascending => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (sort_ascending), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap sort_filesize => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (sort_filesize), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap star_gold => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (star_gold), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap text_ending => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (text_ending), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap text_starting => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (text_starting), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap tga => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (tga), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap tgaL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (tgaL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap tiff => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (tiff), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap tiffL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (tiffL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap up_16 => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (up_16), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap wav => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (wav), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap wavL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (wavL), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap xml => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (xml), LoneRobot.UI.My.Resources.Resources.resourceCulture));

    internal static Bitmap XmlL => (Bitmap) RuntimeHelpers.GetObjectValue(LoneRobot.UI.My.Resources.Resources.ResourceManager.GetObject(nameof (XmlL), LoneRobot.UI.My.Resources.Resources.resourceCulture));
  }
}
