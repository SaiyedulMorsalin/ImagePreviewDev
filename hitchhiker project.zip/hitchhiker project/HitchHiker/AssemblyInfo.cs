﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: ComVisible(false)]
[assembly: AssemblyDescription("")]
[assembly: Guid("139201ae-5f09-4672-81b0-f34e34b2da35")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2010")]
[assembly: AssemblyProduct("HitchHiker")]
[assembly: AssemblyCompany("LoneRobot")]
[assembly: AssemblyTitle("HitchHiker")]
[assembly: AssemblyFileVersion("4.0.0.4")]
[assembly: AssemblyVersion("2.0.0.0")]
